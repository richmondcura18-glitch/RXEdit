package com.rxedit.app

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream

/**
 * Reader/writer for the common Pokémon Essentials Scripts.rxdata shape:
 * Marshal array of [script_id, script_name, zlib_compressed_source] triples.
 * Unsupported layouts are rejected rather than silently rewriting them.
 */
object RubyScriptsFormat {
    data class Entry(val id: Int, val name: String, val compressed: ByteArray)

    fun read(bytes: ByteArray): List<Entry> {
        require(bytes.size >= 4 && bytes[0] == 4.toByte() && bytes[1] == 8.toByte()) {
            "Ruby Marshal 4.8 header not found"
        }
        val r = Reader(bytes.copyOfRange(2, bytes.size))
        val count = r.arrayHeader()
        require(count in 1..10000) { "Unexpected scripts array size: $count" }
        val entries = ArrayList<Entry>(count)
        repeat(count) {
            val inner = r.arrayHeader()
            require(inner == 3) { "Script entry ${it + 1} has $inner fields; expected 3" }
            val id = r.integer()
            val name = r.string()
            val compressed = r.stringBytes()
            require(compressed.size >= 2 && compressed[0] == 0x78.toByte()) {
                "Script $id does not contain expected zlib-compressed source"
            }
            entries.add(Entry(id, name, compressed))
        }
        require(r.remaining() == 0) { "Unexpected trailing data in Scripts.rxdata" }
        require(entries.map { it.id }.toSet().size == entries.size) { "Duplicate script IDs" }
        return entries
    }

    fun write(entries: List<Entry>): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(4, 8))
        val w = Writer(out)
        w.array(entries.size)
        entries.forEach { e ->
            w.array(3)
            w.integer(e.id)
            w.string(e.name.toByteArray(Charsets.UTF_8))
            w.string(e.compressed)
        }
        return out.toByteArray()
    }

    private class Reader(data: ByteArray) {
        private val input = DataInputStream(ByteArrayInputStream(data))
        fun remaining() = input.available()
        private fun ubyte() = input.readUnsignedByte()
        private fun rubyLong(): Long {
            val c = input.readByte().toInt()
            if (c == 0) return 0
            if (c > 4) return (c - 5).toLong()
            if (c < -4) return (c + 5).toLong()
            if (c > 0) {
                var v = 0L
                repeat(c) { i -> v = v or (input.readUnsignedByte().toLong() shl (8 * i)) }
                return v
            }
            val n = -c
            var v = -1L
            repeat(n) { i ->
                val x = input.readUnsignedByte().toLong()
                val mask = 0xffL shl (8 * i)
                v = (v and mask.inv()) or (x shl (8 * i))
            }
            return v
        }
        private fun length(): Int {
            val n = rubyLong()
            require(n in 0..20_000_000) { "Invalid Marshal string/array length: $n" }
            return n.toInt()
        }
        fun arrayHeader(): Int {
            require(ubyte() == '['.code) { "Expected a Ruby Marshal array" }
            return length()
        }
        fun integer(): Int {
            require(ubyte() == 'i'.code) { "Expected script ID integer" }
            return rubyLong().toInt()
        }
        fun string(): String = stringBytes().toString(Charsets.UTF_8)
        fun stringBytes(): ByteArray {
            var tag = ubyte()
            val wrapped = tag == 'I'.code
            if (wrapped) tag = ubyte()
            require(tag == '"'.code) { "Expected a Ruby Marshal string (tag ${tag.toChar()})" }
            val n = length()
            require(n <= input.available()) { "String length exceeds remaining file data" }
            val bytes = ByteArray(n).also { input.readFully(it) }
            if (wrapped) {
                val ivars = length()
                require(ivars in 0..20) { "Unexpected string instance-variable count" }
                repeat(ivars) {
                    // Ruby Marshal instance variable key is normally a symbol, value true/false/string.
                    val keyTag = ubyte()
                    require(keyTag == ':'.code) { "Unsupported string instance variable key" }
                    val keyLen = length()
                    require(keyLen in 0..1000 && keyLen <= input.available()) { "Invalid symbol length" }
                    val key = ByteArray(keyLen).also { input.readFully(it) }.toString(Charsets.UTF_8)
                    when (key) {
                        "E" -> { val v = ubyte(); require(v == 'T'.code || v == 'F'.code) }
                        "encoding" -> { val v = ubyte(); require(v == '"'.code); val l = length(); require(l in 0..100 && l <= input.available()); input.skipBytes(l) }
                        else -> throw IllegalArgumentException("Unsupported string instance variable :$key")
                    }
                }
            }
            return bytes
        }
    }

    private class Writer(private val out: ByteArrayOutputStream) {
        private fun rubyLong(value: Long) {
            if (value == 0L) { out.write(0); return }
            if (value in 1..122) { out.write((value + 5).toInt()); return }
            if (value in -123..-1) { out.write((value - 5).toInt() and 0xff); return }
            var v = value
            val bytes = ByteArray(8)
            var n = 0
            if (value > 0) {
                while (v != 0L && n < 8) { bytes[n++] = (v and 0xff).toByte(); v = v ushr 8 }
                out.write(n)
            } else {
                while (n < 8) {
                    val b = (v and 0xff).toByte()
                    bytes[n++] = b
                    v = v shr 8
                    if (v == -1L && b.toInt() < 0) break
                }
                out.write(-n)
            }
            out.write(bytes, 0, n)
        }
        fun array(n: Int) { out.write('['.code); rubyLong(n.toLong()) }
        fun integer(n: Int) { out.write('i'.code); rubyLong(n.toLong()) }
        fun string(bytes: ByteArray) { out.write('"'.code); rubyLong(bytes.size.toLong()); out.write(bytes) }
    }
}
