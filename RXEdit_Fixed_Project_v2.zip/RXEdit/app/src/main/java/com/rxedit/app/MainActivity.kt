package com.rxedit.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.provider.DocumentsContract
import android.database.Cursor
import android.widget.*
import android.graphics.Typeface
import java.io.ByteArrayOutputStream
import java.util.zip.InflaterInputStream
import java.util.zip.DeflaterOutputStream

class MainActivity : Activity() {
    private var selectedUri: Uri? = null
    private var selectedName: String = "No file selected"
    private var folderUri: Uri? = null
    private lateinit var pathView: TextView
    private lateinit var statusView: TextView
    private lateinit var output: TextView
    private val openFile = 1001
    private val pickUnpackFolder = 1002
    private val pickRepackFolder = 1003
    private var pendingAction = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 20)
            setBackgroundColor(0xFFFFF7FA.toInt())
        }
        root.addView(TextView(this).apply {
            text = "RX EDIT"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF202020.toInt()); gravity = android.view.Gravity.CENTER
        }, matchWrap())
        root.addView(TextView(this).apply {
            text = "Pokémon Essentials data toolkit"; textSize = 13f
            gravity = android.view.Gravity.CENTER; setTextColor(0xFF666666.toInt())
        }, matchWrap())
        pathView = TextView(this).apply {
            text = selectedName; textSize = 13f; setPadding(12, 18, 12, 18)
            setTextColor(0xFF333333.toInt())
        }
        root.addView(pathView, matchWrap())
        root.addView(rowButton("SELECT FILE", "UNPACK", "REPACK") { which ->
            when (which) {
                0 -> chooseFile()
                1 -> { pendingAction = "unpack"; chooseFolder(pickUnpackFolder) }
                2 -> { pendingAction = "repack"; chooseFolder(pickRepackFolder) }
            }
        })
        root.addView(bigButton("ITEMS (.DAT) – VIEW / EDIT") { inspectSelected("ITEMS") })
        root.addView(bigButton("SCRIPTS (.RXDATA) – VIEW") { inspectSelected("SCRIPTS") })
        root.addView(bigButton("TRANSLATE / TEXT PREVIEW") { previewText() })
        statusView = TextView(this).apply {
            text = "Select Scripts.rxdata, then tap UNPACK and choose an output folder."
            textSize = 13f; setPadding(8, 12, 8, 12); setTextColor(0xFF555555.toInt())
        }
        root.addView(statusView, matchWrap())
        output = TextView(this).apply {
            textSize = 11f; typeface = Typeface.MONOSPACE; setTextColor(0xFF222222.toInt())
            setPadding(10, 10, 10, 10); text = "Ready."
        }
        root.addView(ScrollView(this).apply { addView(output) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply { this.text = text; textSize = 13f; setOnClickListener { action() } }
    private fun bigButton(text: String, action: () -> Unit): Button =
        button(text, action).also { it.setPadding(8, 8, 8, 8) }
    private fun rowButton(a: String, b: String, c: String, action: (Int) -> Unit): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf(a, b, c).forEachIndexed { i, label ->
                addView(button(label) { action(i) }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }

    private fun chooseFile() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, openFile)
    }
    private fun chooseFolder(request: Int) {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }, request)
    }

    @Deprecated("Legacy result callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == openFile) {
            selectedUri = uri
            try { contentResolver.takePersistableUriPermission(uri, data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)) } catch (_: Exception) {}
            selectedName = uri.lastPathSegment ?: "Selected file"
            pathView.text = selectedName
            statusView.text = "Selected $selectedName. UNPACK extracts .rb files to a folder you choose."
            output.text = "Ready: $selectedName"
        } else if (requestCode == pickUnpackFolder) {
            folderUri = uri
            try { contentResolver.takePersistableUriPermission(uri, data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)) } catch (_: Exception) {}
            runUnpack(uri)
        } else if (requestCode == pickRepackFolder) {
            folderUri = uri
            try { contentResolver.takePersistableUriPermission(uri, data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)) } catch (_: Exception) {}
            runRepack(uri)
        }
    }

    private fun readSelected(): ByteArray? {
        val uri = selectedUri ?: return null
        return contentResolver.openInputStream(uri)?.use { it.readBytes() }
    }

    private fun runUnpack(tree: Uri) {
        val bytes = readSelected() ?: run { statusView.text = "Select Scripts.rxdata first."; return }
        try {
            val entries = RubyScriptsFormat.read(bytes)
            var count = 0
            entries.forEach { e ->
                val safe = e.name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(100).ifBlank { "script" }
                val filename = "%03d_%s.rb".format(e.id, safe)
                val fileUri = createDocument(tree, "text/x-ruby", filename)
                val script = InflaterInputStream(e.compressed.inputStream()).use { it.readBytes() }
                contentResolver.openOutputStream(fileUri, "wt")!!.use { it.write(script) }
                count++
            }
            statusView.text = "Unpacked $count scripts successfully."
            output.text = "Unpacked $count scripts to the folder you selected.\nEdit the .rb files, then tap REPACK and select this same folder."
        } catch (e: Exception) {
            statusView.text = "UNPACK failed safely: ${e.message}"
            output.text = "This file was not modified. Check that you selected the original Scripts.rxdata.\n${e.stackTraceToString().take(3000)}"
        }
    }

    private fun runRepack(tree: Uri) {
        val source = readSelected() ?: run { statusView.text = "Select the original Scripts.rxdata first."; return }
        try {
            val original = RubyScriptsFormat.read(source)
            val files = listDocuments(tree).filter { it.first.endsWith(".rb", true) }.associateBy { it.first }
            var changed = 0
            val rebuilt = original.map { e ->
                val prefix = "%03d_".format(e.id)
                val file = files.entries.firstOrNull { it.key.startsWith(prefix) }?.value
                if (file == null) e else {
                    val text = contentResolver.openInputStream(file.second)!!.use { it.readBytes() }
                    val compressed = ByteArrayOutputStream().also { bos ->
                        DeflaterOutputStream(bos).use { it.write(text) }
                    }.toByteArray()
                    changed++
                    e.copy(compressed = compressed)
                }
            }
            if (changed == 0) throw IllegalArgumentException("No matching numbered .rb files found in that folder.")
            val outBytes = RubyScriptsFormat.write(rebuilt)
            val outUri = createDocument(tree, "application/octet-stream", "Scripts_repacked.rxdata")
            contentResolver.openOutputStream(outUri, "wt")!!.use { it.write(outBytes) }
            statusView.text = "Repacked $changed scripts. Original file was not overwritten."
            output.text = "Created Scripts_repacked.rxdata in the selected folder.\nTest with a backup of your game. Scripts with filenames that do not match an original ID are left unchanged."
        } catch (e: Exception) {
            statusView.text = "REPACK failed safely: ${e.message}"
            output.text = "The original file was not changed.\n${e.stackTraceToString().take(3000)}"
        }
    }

    private fun createDocument(tree: Uri, mime: String, name: String): Uri {
        val existing = listDocuments(tree).firstOrNull { it.first == name }
        if (existing != null) return existing.second
        return DocumentsContract.createDocument(contentResolver, tree, mime, name)
            ?: throw IllegalStateException("Could not create $name in selected folder")
    }

    private fun listDocuments(tree: Uri): List<Pair<String, Uri>> {
        val result = mutableListOf<Pair<String, Uri>>()
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        contentResolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE), null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getString(0); val name = c.getString(1); val mime = c.getString(2)
                if (mime != DocumentsContract.Document.MIME_TYPE_DIR) result.add(name to DocumentsContract.buildDocumentUriUsingTree(tree, id))
            }
        }
        return result
    }

    private fun inspectSelected(kind: String) {
        val bytes = readSelected() ?: run { statusView.text = "Select a file first."; return }
        output.text = RubyMarshalInspector.inspect(bytes)
        statusView.text = "$kind file inspected (${bytes.size} bytes)."
    }
    private fun previewText() {
        val bytes = readSelected() ?: run { statusView.text = "Select a file first."; return }
        val text = bytes.toString(Charsets.ISO_8859_1)
        output.text = text.filter { it == '\n' || it == '\r' || it == '\t' || it.code in 32..126 }.take(12000).ifBlank { "No plain-text content found." }
        statusView.text = "Showing printable text only; compressed data may not appear."
    }
}
