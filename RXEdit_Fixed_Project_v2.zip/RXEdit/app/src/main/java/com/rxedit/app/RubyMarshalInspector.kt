package com.rxedit.app

import java.io.ByteArrayInputStream
import java.io.DataInputStream
import java.util.zip.InflaterInputStream

/**
 * Defensive Ruby Marshal v4.8 inspector.
 * It intentionally reads a safe subset and reports unsupported tags instead of
 * pretending every Essentials generation has an identical schema.
 */
object RubyMarshalInspector {
    fun inspect(bytes: ByteArray): String {
        if (bytes.size < 2 || bytes[0].toInt() != 4 || bytes[1].toInt() != 8) {
            return "Not a Ruby Marshal 4.8 stream (header 04 08 not found).\\n\\n" + hex(bytes)
        }
        val parser = Parser(bytes.copyOfRange(2, bytes.size))
        return buildString {
            appendLine("Ruby Marshal 4.8")
            appendLine("Bytes: ${bytes.size}")
            appendLine()
            append(parser.parse())
        }
    }

    private fun hex(b: ByteArray): String = b.take(128).joinToString(" ") { "%02x".format(it) }

    private class Parser(data: ByteArray) {
        private val input = DataInputStream(ByteArrayInputStream(data))
        private var count = 0
        private val maxNodes = 20000
        private fun byte() = input.readUnsignedByte()
        private fun rubyLong(): Long {
            val c = input.readByte().toInt()
            if (c == 0) return 0
            if (c > 0) {
                var v = 0L
                repeat(c) { i -> v = v or (input.readUnsignedByte().toLong() shl (8 * i)) }
                return v
            }
            val n = -c
            var v = -1L
            repeat(n) { i ->
                val x = input.readUnsignedByte().toLong()
                val mask = 0xffL shl (8 * i)
                v = (v and mask.inv()) or (x shl (8 * i))
            }
            return v
        }
        private fun bytes(n: Int): ByteArray {
            require(n >= 0 && n <= 8_000_000) { "Invalid string length: $n" }
            return ByteArray(n).also { input.readFully(it) }
        }
        private fun str(): String {
            val n = rubyLong().toInt()
            return bytes(n).toString(Charsets.UTF_8)
        }
        fun parse(): String {
            val out = StringBuilder()
            try { node(out, 0) } catch (e: Exception) {
                out.appendLine().appendLine("[Stopped safely: ${e.message}]")
            }
            return out.toString()
        }
        private fun node(out: StringBuilder, depth: Int) {
            require(depth < 80) { "Nesting limit reached" }
            count++
            require(count <= maxNodes) { "Node limit reached" }
            when (val tag = byte().toChar()) {
                '0' -> out.append("nil")
                'T' -> out.append("true")
                'F' -> out.append("false")
                'i' -> out.append("integer ").append(rubyLong())
                '"' -> out.append("string \"").append(str().take(300).replace("\n", "\\n")).append("\"")
                ':' -> out.append("symbol :").append(str())
                '[' -> {
                    val n = rubyLong().toInt()
                    out.appendLine("array[$n] [")
                    repeat(n.coerceIn(0, 5000)) { out.append("  ".repeat(depth + 1)); node(out, depth + 1); out.appendLine() }
                    out.append("  ".repeat(depth)).append("]")
                }
                '{' -> {
                    val n = rubyLong().toInt()
                    out.appendLine("hash[$n] {")
                    repeat(n.coerceIn(0, 5000)) {
                        out.append("  ".repeat(depth + 1)); node(out, depth + 1)
                        out.append(" => "); node(out, depth + 1); out.appendLine()
                    }
                    out.append("  ".repeat(depth)).append("}")
                }
                'f' -> out.append("float ").append(str())
                '@' -> out.append("object-link #").append(rubyLong())
                ';' -> out.append("symbol-link #").append(rubyLong())
                'I' -> {
                    node(out, depth + 1)
                    val n = rubyLong().toInt()
                    out.appendLine(" [instance variables: $n]")
                    repeat(n.coerceIn(0, 1000)) { out.append("  ".repeat(depth + 1)); node(out, depth + 1); out.append(" = "); node(out, depth + 1); out.appendLine() }
                }
                'o' -> {
                    out.append("object ")
                    node(out, depth + 1)
                    val n = rubyLong().toInt()
                    out.appendLine(" fields=$n")
                    repeat(n.coerceIn(0, 1000)) { out.append("  ".repeat(depth + 1)); node(out, depth + 1); out.append(" = "); node(out, depth + 1); out.appendLine() }
                }
                'u', 'U', 'd', 'S', 'c', 'm', 'M', 'C', 'e' ->
                    out.append("unsupported Ruby Marshal tag '").append(tag).append("' (remaining bytes ").append(input.available()).append(")")
                else -> out.append("unknown tag '").append(tag).append("'")
            }
        }
    }
}
