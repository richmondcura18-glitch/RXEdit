# RX Edit – Android Studio starter project

This is a native Android starter for a multi-game Pokémon Essentials data toolkit.

## Current prototype capabilities
- Android Storage Access Framework file picker (works with scoped storage).
- Recognizes Ruby Marshal 4.8 headers.
- Defensive structural inspection for common Marshal values (nil, booleans, integers, strings, symbols, arrays, hashes, objects and instance variables).
- Printable text preview.
- Does not overwrite source files.

## Important compatibility note
“Pokémon Essentials” covers multiple generations and game-specific modifications. `.rxdata`, `.dat`, `.rvdata`, `.rvdata2`, and compressed script payloads are not guaranteed to share one schema. This prototype is a safe foundation, not yet a universal editor. Full unpack/repack and item/script editing require version-aware parsing, Ruby Marshal object-link handling, zlib payload handling, and game-specific schema adapters. The app deliberately disables repack until a lossless writer and validation are implemented.

## Build APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the generated APK location, usually `app/build/outputs/apk/debug/app-debug.apk`.

## Next development milestones
1. Complete lossless Ruby Marshal reader/writer with object and symbol link tables.
2. Add zlib decompression/recompression for script records.
3. Add version profiles for Essentials generations and common forks.
4. Implement item model adapters and editable fields.
5. Implement safe repack to a new output file with validation and backup.
6. Add translation extraction/import and script editor with syntax highlighting.

## Uploaded sample files
The project is not bundled with the user's game data. Select files from device storage inside the app.
