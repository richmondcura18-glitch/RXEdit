package com.rxedit.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.widget.*
import android.graphics.Typeface
import java.io.ByteArrayOutputStream
import java.util.zip.InflaterInputStream
import java.util.zip.DeflaterOutputStream

class MainActivity : Activity() {
    private var selectedUri: Uri? = null
    private var selectedName: String = "No file selected"
    private lateinit var pathView: TextView
    private lateinit var statusView: TextView
    private lateinit var output: TextView
    private val openFile = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 26, 20, 20)
            setBackgroundColor(0xFFFFF7FA.toInt())
        }
        val title = TextView(this).apply {
            text = "RX EDIT"
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(0xFF202020.toInt())
            gravity = android.view.Gravity.CENTER
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "Pokémon Essentials data toolkit"
            textSize = 13f
            gravity = android.view.Gravity.CENTER
            setTextColor(0xFF666666.toInt())
        }
        root.addView(subtitle, matchWrap())
        pathView = TextView(this).apply {
            text = selectedName
            textSize = 13f
            setPadding(12, 18, 12, 18)
            setTextColor(0xFF333333.toInt())
        }
        root.addView(pathView, matchWrap())
        root.addView(rowButton("SELECT FILE", "UNPACK", "REPACK") { which ->
            when (which) {
                0 -> chooseFile()
                1 -> unpackSelected()
                2 -> repackSelected()
            }
        })
        root.addView(bigButton("ITEMS (.DAT) – VIEW / EDIT") { inspectSelected("ITEMS") })
        root.addView(bigButton("SCRIPTS (.RXDATA) – VIEW") { inspectSelected("SCRIPTS") })
        root.addView(bigButton("TRANSLATE / TEXT PREVIEW") { previewText() })
        statusView = TextView(this).apply {
            text = "Choose a game data file to begin."
            textSize = 13f
            setPadding(8, 12, 8, 12)
            setTextColor(0xFF555555.toInt())
        }
        root.addView(statusView, matchWrap())
        output = TextView(this).apply {
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(0xFF222222.toInt())
            setPadding(10, 10, 10, 10)
            text = "File information will appear here."
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply { this.text = text; textSize = 13f; setOnClickListener { action() } }
    private fun bigButton(text: String, action: () -> Unit): Button =
        button(text, action).also { it.setPadding(8, 8, 8, 8) }

    private fun rowButton(a: String, b: String, c: String, action: (Int) -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            listOf(a, b, c).forEachIndexed { i, label ->
                addView(button(label) { action(i) }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, openFile)
    }

    @Deprecated("Legacy result callback kept for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == openFile && resultCode == Activity.RESULT_OK) {
            data?.data?.let { uri ->
                selectedUri = uri
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                selectedName = uri.lastPathSegment ?: "Selected file"
                pathView.text = selectedName
                statusView.text = "File selected. Original data will not be overwritten automatically."
                output.text = "Ready: $selectedName"
            }
        }
    }

    private fun readSelected(): ByteArray? {
        val uri = selectedUri ?: return null
        return contentResolver.openInputStream(uri)?.use { it.readBytes() }
    }

    private fun unpackSelected() {
        val bytes = readSelected() ?: run { statusView.text = "Select a file first."; return }
        try {
            val decoded = RubyMarshalInspector.inspect(bytes)
            output.text = decoded
            statusView.text = "Parsed Ruby Marshal structure where supported. No source file changed."
        } catch (e: Exception) {
            statusView.text = "Could not parse this file: ${e.message}"
        }
    }

    private fun repackSelected() {
        statusView.text = "Repack is not enabled yet. Safe writing requires format/version validation to avoid corrupting game saves."
    }

    private fun inspectSelected(kind: String) {
        val bytes = readSelected() ?: run { statusView.text = "Select a file first."; return }
        output.text = RubyMarshalInspector.inspect(bytes)
        statusView.text = "$kind file inspected (${bytes.size} bytes). Editing/export is being built."
    }

    private fun previewText() {
        val bytes = readSelected() ?: run { statusView.text = "Select a file first."; return }
        val text = bytes.toString(Charsets.ISO_8859_1)
        val printable = text.filter { it == '\n' || it == '\r' || it == '\t' || it.code in 32..126 }
        output.text = printable.take(12000).ifBlank { "No plain-text content found." }
        statusView.text = "Showing printable text only; binary/compressed data may not appear."
    }
}
